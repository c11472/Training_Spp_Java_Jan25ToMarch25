
public class Init2DArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//init
		double salary[] = {45000.56,67000.90,34000.0};
		
		String EmpNMList[][] = {{"Prachi","Pragyan"},
				{"Arti","Mishra"},
				{"Test","Data"}};
		
		for(int i=0;i<=2;i++) {
			for(int j=0;j<=1;j++) {
				System.out.print(EmpNMList[i][j]+ " ");
			}
			System.out.println();
		}
		
		for(double i:salary) {
			System.out.print(i + " ");
			
		}
		

	}

}
