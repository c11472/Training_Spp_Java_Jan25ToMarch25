package AccessDemo;

public class DataAccessMain extends TestAccessOne  {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Test objtest = new Test();
	    System.out.println(objtest.nm); //data
	    System.out.println(objtest.num);//90
	    System.out.println(objtest.sal);
	    
	    
	   DataAccessMain test12=new DataAccessMain();
	    
	   test12.
	    
	    

	}

}
