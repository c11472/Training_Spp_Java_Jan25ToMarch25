package AccessDemo;

public class TestData {
	
	public int num=90;
	private String eid="testempnm";
	protected String nm="data";
	double sal=908700.00;
	

}
