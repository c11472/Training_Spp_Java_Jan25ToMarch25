package AccessDemo;
 class Test{
	
	//Data members
	public int num=90;
	private String eid="testempnm";
	protected String nm="data";
	double sal=908700.00;
	
	
	
	
}



public class TestAccessOne  {
public static void main(String[] args) {
	Test t1= new Test();
	System.out.println(t1.nm);
	System.out.println(t1.nm);
	
	 
	
}	

}
