//Method Overriding
class BookBase1 {
	
	public void testDisplay(int num,String nm) {
		System.out.println("No data to be displayed");
	}
	

}

class BookDerived1 extends BookBase1{
	public void testDisplay(int num,String nm) {
		System.out.println("Successfully tested overriding feature in Java !");
	}	
}

class MainTest extends BookDerived1 {
	
	public void testDisplay(int num,String nm) {
		System.out.println("NA __________");
	}	

	public static void main(String args[]) {
		
		
		//BookBase1
		BookBase1 bb1 = new BookBase1();
		bb1.testDisplay(90,"t1");
		
		BookDerived1 bd1 = new BookDerived1();
		bd1.testDisplay(100,"t2");
		
		
		BookBase1 bb2 = new BookDerived1();
		bb2.testDisplay(1000,"t3");	
		
		BookDerived1 obj = new MainTest();
		obj.testDisplay(89,"test67");
		
		
	}
	
}


