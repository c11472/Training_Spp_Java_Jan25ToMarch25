package Day1SampleCode;

public class PolymerphismDemoTest {
	
	//method1
	
	public void DisplayData() {
		System.out.println("No data to display");
	}
	
	//method2
	
	public void DisplayData(int num1) {
		num1=1090;
		System.out.println("val of num1" + num1);
	}
	public void DisplayData(double num5) {
		num5=1090.90;
		System.out.println("val of num1" + num5);
	}
	
	
	
	
	
	
	//method3
	
	public void DisplayData(int num2,double num3) {
		num2=100;
		num3=900;
		double sum= num2+num3;
		System.out.println("val of sum" + sum);
	}
	
	
	public void DisplayData(double x1,int y1) {
		x1=100.09;
		y1=900;
		double sum= x1+y1;
		System.out.println("val of sum" + sum);
	}
	
	
	

}
