package Day1SampleCode;

public class AccessPoly {

	public static void main(String args[]) {
		PolymerphismDemoTest obj = new PolymerphismDemoTest();
		
		obj.DisplayData();
		obj.DisplayData(45);
		obj.DisplayData(1, 2.90);
		obj.DisplayData(90.90,90);
		
	}
}
