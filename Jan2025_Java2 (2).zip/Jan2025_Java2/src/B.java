
class B1 {
	private int data1=100;
	int b=900;
	public int a=98;
	protected int data2=89;
	
		
	

}

class B extends B1{
	public static void main(String args[]) {
		B objDemo = new B();
		System.out.println(objDemo.data2);
		
	}
	
}
