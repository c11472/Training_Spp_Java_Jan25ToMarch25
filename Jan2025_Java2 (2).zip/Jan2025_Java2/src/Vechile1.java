
public class Vechile1 extends VechileInfo {
	
	Vechile1(String vnm, double vt) {
		super(vnm, vt);
	}

	String VechileCol;
	

}
