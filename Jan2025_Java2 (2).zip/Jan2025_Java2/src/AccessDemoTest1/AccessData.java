
package AccessDemoTest1;

import AccessDemo.TestAccessOne;
import AccessDemo.TestData;

public class AccessData {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//AccessData objAccessData = new AccessData();
		
		TestData test56 = new TestData();
		
		AccessData obj57 = new AccessData();
	    System.out.println(test56.num);
		

	}

}
