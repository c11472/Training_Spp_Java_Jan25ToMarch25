import java.util.Scanner;

public class TwoDArrayDemo {

	public static void main(String[] args) {
		
		/****
		 * Enter the values in 3 * 3 2d 
		 * array and display the data
		 * 
		 */
		
		//String empnm[] = new String[9];
		int tabledata[][]=new int[4][4];
		//accept elements 
		
		//index ---- rowind--- i colind---j
		
		int i,j;
		
		Scanner c = new Scanner(System.in);
		
		//Traverse the array and enter the data
		System.out.println("Enter the elements into the array tabledata");
		for( i=0;i<=2;i++) {
			for(j=0;j<=2;j++) {
				tabledata[i][j]=c.nextInt();
				
			}
			
		}
		
		// Traverse the array and display the data
		
		for(i=0;i<=2;i++) {
			for(j=0;j<=2;j++) {
				System.out.print(tabledata[i][j] + " ");
				
			}
			System.out.println(); //
		}
		
		System.out.println(tabledata[1][1]);
	
	}

}
