
public class AccessData {

	public static void main(String[] args) {
		Vechile2 obj = new Vechile2("testdata1",670000.00);
		

		//name will take from constructor
		//obj.VechileName="texa";
		//price take from constructor
		//obj.VechilePrice=900000.00;
		//col
		obj.VechileCol="green";
		//ownre
		obj.OwnerName="Test Owner";
		
		System.out.println(obj.VechileName + " " +obj.VechilePrice+ " "+ obj.VechileCol+" "+
		obj.OwnerName);
		System.out.println(obj.VechileName);
		System.out.println(obj.VechilePrice);
		
		

	}

}
