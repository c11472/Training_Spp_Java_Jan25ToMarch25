
public class Vechile2 extends Vechile1{
	
	Vechile2(String vnm, double vt) {
		super(vnm, vt);
		// TODO Auto-generated constructor stub
	}

	String OwnerName;
	

}
