package Interfacedemo;

public interface  TestInterface1 {
	//abstract methods
	
	abstract void display();
	
}
