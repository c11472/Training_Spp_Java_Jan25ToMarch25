package EncapsulationDemo;

public class EmployeeDetails {
	
	//To declare the varibles related to EmployeeDetails
	//private members
	private String EmpName; //2
	private int EmpID;
	private double EmpSal;
	private int deptid[]; // multiple values
	private String deptcode; //2
	
	
	
	// set the name
	
	public void SetEmpName(String enm) {
		this.EmpName=enm;
	
	}
	
	public String GetEmpName() {
		
		return EmpName;
		
	}
	
	public void SetEmpID(int EmpID) {
		this.EmpID=EmpID;
		
	}
	
	public int GetEmpID() {
		return EmpID;
	}
	
	public void SetSal(double EmpSal) {
		this.EmpSal=EmpSal;
		
	}
	
	public double GetSal() {
		return EmpSal;
	}
	
	public void SetDeptID(int deptid[] ) {
		this.deptid=deptid;
		
	}
	
	public int[] GetDeptID() {
		return deptid;
	}

}
