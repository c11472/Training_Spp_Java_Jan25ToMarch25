package EncapsulationDemo;

public class AccessEmployeeDetails {
	public static void main(String args[]) {
		
		// create object for EmployeeDetails
		
		
		
		EmployeeDetails ob = new EmployeeDetails();
		
		ob.SetEmpName("Prachi D"); // data stored 
		
		
		
		int deptid[] = {1145,5643,7856,1980}; //values
		
		String name = ob.GetEmpName();
		
		System.out.println("Emp name is" + " "+ ob.GetEmpName());
		
        ob.SetEmpID(1124);
        
        int id = ob.GetEmpID();
        
        System.out.println(" ID is " + id);
        
        ob.SetSal(85000.00);
        
        double sal = ob.GetSal();
        System.out.println("Sal is " + sal);
        
        
        //Array access
        
        ob.SetDeptID(deptid); // taking values
        
        int res[] = ob.GetDeptID();
        
        for(int i:res) {
        	System.out.print(i + " ");
        }
        
        
		
	}

}
