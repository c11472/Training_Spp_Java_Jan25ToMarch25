package Abstractiondemo;

public class CallMethodsUsingMain {

	public static void main(String[] args) {
		
		ImplementAccountDetails ob = new ImplementAccountDetails();
		
		ob.DisplayBankName();
		
		ob.AccNum();
		
		int n=ob.id();
		System.out.println(n);
		
		ob.displaydata();
		

	}

}
