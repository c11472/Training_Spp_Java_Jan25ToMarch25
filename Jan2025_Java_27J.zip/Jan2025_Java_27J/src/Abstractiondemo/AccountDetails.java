package Abstractiondemo;

 abstract class AccountDetails {
	
	abstract void DisplayBankName(); //1
	abstract void AccNum();//2
	abstract void DepositeAmt();//3
	abstract int id(); //4 ----
	
	public void displaydata() {
		System.out.println("hi there ! This is an abstract class");
	}
	

}
