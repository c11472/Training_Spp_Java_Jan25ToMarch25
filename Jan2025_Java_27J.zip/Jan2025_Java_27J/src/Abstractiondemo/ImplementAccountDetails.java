package Abstractiondemo;

public class ImplementAccountDetails extends AccountDetails {

	String Bnm;
	String accnum ;
	double deposit;
	void DisplayBankName() {
		
	    Bnm = "SBI";
		System.out.println("Bank name is " + " "+ Bnm);
		
	}

	void AccNum() {
		accnum="5646757578669";
		System.out.println("Account number :"+ accnum) ;
	}

	void DepositeAmt() {
		deposit = 89000.00;
		System.out.println("The deposite amt is "+ deposit);
			
	}

	int id() {
	    int id=99;
		return id;
	}

}
