package InterfaceDefaultAndStaticMethods;

public class AccessTestInterface  implements TestInterface{

	public void pincode() {
		// TODO Auto-generated method stub
		System.out.println("750765");
		
		
		
	}
	
	
	
	
   public static void main(String[] args) {
	   
	   AccessTestInterface test1 = new AccessTestInterface();
	   test1.pincode();

	   test1.testdata1();
	   
	  TestInterface.testinfo(); 
	   
	   
	
}

}
