package InterfaceDefaultAndStaticMethods;

public interface TestInterface {
	abstract void pincode();
	
	// method must be static
	
	// method must be default
	
	default void testdata1() {
		System.out.println("9191919191");
	}
	
	
	
	public static void testinfo() {
		System.out.println("hi");
	}

}
