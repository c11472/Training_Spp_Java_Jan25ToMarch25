package DataParsingDemo;

public class WrapperLib {
	
	public void Convert_To_Double() {
		String s1 = "896.90";
		double dval = Double.parseDouble(s1);
		
		System.out.println(dval);
		//return 1.9;
		
		
	}
	
	public void Convert_To_Int() {
		
		String s11 = "8961";
		
		int ival = Integer.parseInt(s11);
		System.out.println(ival);

		
	}
	
	public float Convert_To_Float() {
		
		String s12 = "9876.65";
		float fval = Float.parseFloat(s12);
		return fval;
	}
	
	
	/******Convert from primitive to string ******/
	public String ConvertData1() {
		
		int pricetag = 997; //existing data
		String converteddata = String.valueOf(pricetag);
		
		return converteddata;		
	}
	
	
	
public String ConvertData2() {
		
		double pricetag1 = 997.90; //existing data
		String converteddata = String.valueOf(pricetag1);
		return converteddata;	
		
	
}

public String ConvertData3() {
	boolean b = true;
	String res = String.valueOf(b);
	return res;
}





	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
