package DataParsingDemo;

public class ConvertStringToInt {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		WrapperLib wlib = new WrapperLib();
		
        wlib.Convert_To_Double();	
		float f1=wlib.Convert_To_Float();
		
		wlib.Convert_To_Int();
		
		
		String cd1=wlib.ConvertData1();
		System.out.println(cd1);
		
		String cd2=wlib.ConvertData2();
		System.out.println(cd2);
		
		String res1=wlib.ConvertData3();
		System.out.println(res1);

	}

}
