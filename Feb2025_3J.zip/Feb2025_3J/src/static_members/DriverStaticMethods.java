package static_members;

public class DriverStaticMethods extends LibStaticMethods {
	
	public static void main(String[] args) {
		
		int result1=LibStaticMethods.testsrc();
		System.out.println(result1);
		
		
		LibStaticMethods.testDataSource();
		
		testDataSource(); 
		
	}

}
