package static_members;

public class StaticBlockDemo {
	int x=100;
	static {
		System.out.println("Hello this is the first static block1");
		
	}
	
	
	static {
		System.out.println("Hello this is the first static block2");
		
	}
	
	static {
      System.out.println(10+20);		
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("This is the main block !");

	}
	
	static {
		System.out.println("Hello this is the first static block4");
		
	}

}
