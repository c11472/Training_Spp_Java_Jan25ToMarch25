package static_members;

public class StaticVarDemo {
	static double f1 =  100.7;
	
	static int p;
	
	static String p1;
	
	static double p2;
	
	//static members
	
	static int staticm;
	
	int test1;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//non static members
		 int nonstaticm=90;
		
		f1=200.9;
		StaticVarDemo o1 = new StaticVarDemo();// saved
		
		System.out.println(f1 );   
		System.out.println(p);
		System.out.println(p1);
		System.out.println(p2);



	}

}
