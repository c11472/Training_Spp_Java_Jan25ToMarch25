package static_members;

public class DriverStaticVarDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println(StaticVarDemo.f1);
		
		System.out.println(StaticVarDemo.p1);
		
		System.out.println(StaticVarDemo.staticm);

	}

}
