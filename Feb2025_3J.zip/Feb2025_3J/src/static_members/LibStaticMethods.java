package static_members;

public class LibStaticMethods {
	
	
	static void testDataSource() {
		String res1 = "testdata";
		StringBuffer sb1 = new StringBuffer(res1); //mutable , memory will be saved
		System.out.println(sb1.reverse());
	}
	
	
	static int testsrc() {
		int num=900;
		return num;
	}
	
	public void testsrc1() {
		System.out.println("This is a non static method !");
	}

}
