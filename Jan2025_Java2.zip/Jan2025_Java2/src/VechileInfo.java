// Common resources
public class VechileInfo {
	
	String VechileName;
	double VechilePrice;
	
	// constructor
	
	/*VechileInfo(){
		
		VechileName = "Indica0897";
		
		VechilePrice= 800000.00;
				
	}*/
	
	VechileInfo(String vnm , double vt){
		this.VechileName=vnm;
		this.VechilePrice=vt;
		
	}
	
	
	
	
	

}
