import java.util.Scanner;

class Bank1 {

	String BankNM;
	String BankAddr;
	
	//constructor --- member
	Bank1(){
		BankNM="abc";
		BankAddr="Unit2";
		
		
	}
	
	//method
	
	public void testBankIFSC() {
		System.out.println("This bank ifsc is BSK9867");
	}
	

} // Bank1 
 
 class Bank3 extends Bank1{
	 
	 
	 int numofemp; //
	 
	 public void testBankIFSC1() {
			System.out.println("This bank ifsc is BSK9867767");
		}
		
	 
 } //Bank3

public class Bank2 extends Bank3{
	public static void main(String[] args) {
		Bank2 bnk = new Bank2();
		
		Scanner inp = new Scanner(System.in);
		
		//bnk.numofemp=101; //init ---> input
		// Enter the number of emplyees
		System.out.println("Eneter the number of employees");
		bnk.numofemp=inp.nextInt();
		System.out.println(bnk.numofemp);
		
		
	//	bnk.BankNM="ICICA";
	//	bnk.BankAddr="Unit 1 BBSR"; // 2nd var
		System.out.println(bnk.BankAddr);
		System.out.println(bnk.BankNM);
		
		System.out.println(bnk.numofemp);
		
		bnk.testBankIFSC();
		bnk.testBankIFSC1();
		
	
	
		
	} 
	


}