package ExceptionInJava;

public class ArrayIndExp2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayIndExp2 o1 = new ArrayIndExp2();
		o1.DispArray(); //
		o1.dummytest();

	}
	public void DispArray() {
		try {
		int arr[] = {10,54,90,65};
		System.out.println(arr[5]);
		}
		catch(Exception e) {
			//System.out.println("This is an ArrayIndexOutOfBoundsException ! ");
			
			e.printStackTrace();
			//System.out.println("Hello world !");
			
		}
	}//
	
	public void dummytest() {
		System.out.println("dummy data !");
	}
	
}

	

