package ExceptionInJava;

public class NullPExp4 {
	public static void main(String[] args) {
		
		NullPExp4 p4 = new NullPExp4();
		p4.NullPExp();
		
	}
	
	void NullPExp() {
		String v1 = null;
		String v2 = "test";
		boolean testres=v1.equals(v2);
		System.out.println(testres);
	}
	
	
	

}
