package ExceptionInJava;

public class NumberArithmeticExp1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NumberArithmeticExp1 o1 = new NumberArithmeticExp1();
		o1.DispExp();
		
		o1.DispData();
		
		  
	}
	
	void DispExp() {
		try {
		 int num=100;
		 int  num1 = num/0;
		 System.out.println(num1);
		}
		catch(Exception test1) {
			System.out.println("Test data");
			test1.printStackTrace();
			
			
		}
	
	}
	
	void DispData() {
		System.out.println("Not an exception");
	}
	
  

}
