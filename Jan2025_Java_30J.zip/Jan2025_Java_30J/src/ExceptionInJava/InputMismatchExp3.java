package ExceptionInJava;

import java.util.Scanner;

public class InputMismatchExp3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num;
		Scanner c = new Scanner(System.in);
		num=c.nextInt();
		System.out.println(num);
		
		
	}

}
