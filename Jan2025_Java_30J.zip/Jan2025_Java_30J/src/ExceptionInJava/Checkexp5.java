package ExceptionInJava;

import java.io.FileReader;

public class Checkexp5 {
	
	public static void main(String[] args) {
		FileReader fr = new FileReader("D:/testdata/p1.txt");
		
		System.out.println("File found");
		
		
		
		
		
	}

}
