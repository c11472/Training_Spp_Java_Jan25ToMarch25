package BankCaseStudy;

public interface BankAdmin1 {
	
	abstract void BankNoOfAtm();

}
