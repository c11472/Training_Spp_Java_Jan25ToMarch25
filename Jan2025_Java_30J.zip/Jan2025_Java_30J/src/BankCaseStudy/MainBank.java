package BankCaseStudy;

public class MainBank {
	public static void main(String[] args) {
		
		BankDetails bdetails = new BankDetails();
		bdetails.BankName();
		bdetails.BankNoOfAtm();
		bdetails.NoOfEmp();
		
	}

}
