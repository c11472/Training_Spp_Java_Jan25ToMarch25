package BankCaseStudy;

import java.util.Scanner;

public class BankDetails implements BankAdmin1,BankOp {

	public void BankNoOfAtm() {
		
		Scanner c = new Scanner(System.in);
		
		int atmcounts;
		System.out.println("Enter the total number of atms available:");
		atmcounts=c.nextInt();
		System.out.println("No of atms:" + atmcounts);
		
		
	}

	public void BankName() {
		
		Scanner c1 = new Scanner(System.in);
		String BankNm;
		System.out.println("Enter the bank name");
		BankNm = c1.next();
		System.out.println("The bank name is : " + BankNm);
		
	}

	public void NoOfEmp() {
		Scanner c2 = new Scanner(System.in);
		int empcounts;
		System.out.println("Enter total employees working")
		;
		empcounts=c2.nextInt();
		System.out.println("Employees "+ empcounts);
		
		
	}

}
