package BankCaseStudy;

public interface BankOp {
	
	abstract void BankName();
	abstract void NoOfEmp();
}
